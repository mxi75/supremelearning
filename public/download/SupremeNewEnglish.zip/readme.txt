================================
===SUPREMELEARNING GUIDELINES===
================================

________________________________
REGISTRATION

Please take a few moments to register your product with Wayward Ventures Publishing. For having done so, you will receive a free dictionary in your native language of the basic words used in the SupremeLearning course, or a comparable product. You can discuss your options with a company representative. 

Some products are not available in stores; some will only be sold to registered customers. 

Register by either calling toll-free 1-888-743-7868 or 1-888-532-7677, or sending information via email to Wayward13@aol.com, or by sending a postcard to

Wayward Ventures Publishing
29 John Street, Suite 188
New York NY 10038 USA

Here is the information you should supply when registering

1) Name

2) Mailing address 

3) Phone number

4) Email, if available

5) ISBN number of your product, as found above the bar code on the product's back outer cover

6) Registration number, as located on the back (white) side of front cover of your product (Call if you have questions.)

7) Where you bought the product

8) How much you paid for the product

________________________________
IF YOUR PACKAGE HAS A DISKETTE...

...then these instructions appear in the README.TX2 file, are in ASCII/text format, and are readable and printable from any word processor program. 

________________________________
SUPREMELEARNING STEPS FOR AUDIO TAPES AND ACCOMPANYING PRINTED/PRINTABLE INFORMATION

STEP 1

Listen and read along, simultaneously, with the evaluation tape, marked with "Eval". The associated text is located in the Random Words and Sentences section of this book. Note your ability to follow the written text and mimic the speakers. 

STEP 2

Listen and read along simultaneously with all other tapes in your package, consecutively. The associated text is located in the sections entitled Words and Sentences; The Star Spangled Banner; Joyful, Joyful, We Adore Thee; Amazing Grace; and The Raven. 

You can choose to merely to listen and repeat, rather than read-along. In this case, you will learn American English as well, but it will probably take you longer to achieve the desired results. 

STEP 3

Repeat Steps 1 and 2 until you have reached an acceptable (for you) level of American English. 

STEP 4

Read along at least 450 pages with an American English book on audio tape. The book should be narrated by a professional speaker and you should be familiar with the content of the same book in your own native language. 

STEP 5

Repeat Step 4 with the same book. 

Note that if you want to speed up and ease the process of gaining SupremeLearning skills, it is recommended that you additionally watch and read along with the SupremeLearning complementary video editions before beginning Step 1. 

The vast majority of people can start without a video articulation presentation. Some people need to employ just one video tape to develop the SupremeLearning skills necessary to continue studying using the audio tapes. 

________________________________
GENERAL SUPREMELEARNING GUIDELINES

Vary the ways you read along. Sometimes simply listen to the narrator, following the written text with your eyes, but not speaking yourself. Other times, imitate the narrator orally by speaking very quietly, or even only moving your lips. Still other times, imitate the narrator orally by speaking very loudly. 

Don't be shy about mimicking the exact, seemingly strange, methods of speaking. Some sounds have even been electronically changed to work effectively. The special background subliminal sounds vanish on copies made from the original tapes. Effective learning can only be guaranteed when you use the original tapes. 

Don't worry if you do not know what the words that you are reading mean. Imitate without understanding. If by the end of the course your brain didn't figure out the meanings of some words (which will happen with a small percentage of people) you may order from us a copy of a complete dictionary in your native language. If you have this dictionary, you should read it outloud and then repeat Step 2 once. 

Remember that SupremeLearning is the only system that really teaches English effectively. 

Repeat the entire read-along sequence at least four times, over the course of a relatively short period of time. Slow learners and those who began with a lower level of English will need to repeat the learning process more times. 

You will have successfully SupremeLearned American English when you are able to speak perfectly simultaneously with all the different voices on all the tapes of the course and can speak along with, or simulate, an American model speaker (e.g., your instructor, friend, media broadcaster, etc.). 

Even after time has passed since the time you will have used SupremeLearning tapes to learn, and especially if you haven't met people with whom to use all the words learned, you can revisit the evaluation tape and at least one other tape to reactivate your American English. 

If you're simultaneously studying at on-going school or other courses, let the SupremeLearning course become your main supporting and inspiring source. You can incorporate SupremeLearning techniques into any other English improvement courses, or for that matter, courses on any subject taught in English. 

________________________________
IF YOUR PACKAGE HAS AN ARTICULATION, SOUND, RHYTHM, & INTONATION PRESENTATIONAL VIDEO TAPE...

...perform the same read-along process with the video tape as described above with the audio tapes. Do this as a Step 0 before beginning each new SupremeLearning session of Steps1 through 3. 

As mentioned above, most people need just one video tape to develop the SupremeLearning skills. However, the more SupremeLearning video tapes you employ, the faster and better you will learn American English.  

________________________________
TO ACHIEVE THE MAXIMUM LEVEL OF AMERICAN ENGLISH...

...you must use the SupremeLearning software interspersed with the read-along process. 

________________________________
IF YOUR PACKAGE HAS ACCOMPANYING SUPREMELEARNING SOFTWARE...

...listen to a word or a sentence, repeat it a few times outloud, then type the same word or sentence in the SupremeLearning software error-free, while self dictating outloud letter-by-letter. 

The following is an example of this process. "Listen" means you listen to the SupremeLearning audio or video tape. "Speak" means you speak outloud. "Type" means you type using the SupremeLearning software. 

LISTEN riddle
SPEAK  riddle
       riddle
       riddle
SPEAK  r
TYPE   r
SPEAK  i
TYPE   i
SPEAK  d
TYPE   d
SPEAK  d
TYPE   d
SPEAK  l
TYPE   l
SPEAK  e
TYPE   e
LISTEN I'll tell you a riddle if you stop playing your fiddle.
SPEAK  I'll tell you a riddle if you stop playing your fiddle.
I'll tell you a riddle if you stop playing your fiddle.
I'll tell you a riddle if you stop playing your fiddle.
SPEAK  I
TYPE   I
SPEAK  apostrophe
TYPE   '
SPEAK  l
TYPE   l
SPEAK  l
TYPE   l
SPEAK  t
TYPE   t
. . .

Typing all the text of the SupremeLearning course may be performed just once.

After each repetition of Steps 1 and 2, read along with the video or audio tape, and type up to 300 hundred words or 150 word and sentence combinations. 

________________________________
RUNNING THE SUPREMELEARNING SOFTWARE

STEP 1

Place diskette into floppy drive.

STEP 2

From Windows, run the program SUPREME.EXE.

STEP 3

Click on Begin.

STEP 4

Choose a text set from the Text Identifier list.

STEP 5

If you are beginning the text set for the first time, leave the 1 in the Line Number field.

If you want to continue from a point where you had previously typed, type in that line number in the Line Number field. 

STEP 6

Click on Begin. 

STEP 7

Type the text shown on the Fixed Line above the Input Line, and/or appearing in the upper right hand box, and/or given in your accompanying materials. 

The <Ctrl>V combination toggles the visibility of the text on the Fixed Line. Make the text not visible when you want to practice typing for memorization or from accompanying materials, or to master spelling. 

When you make an error, the line will be repeated. 

The program will stop executing when you have clicked on the Exit buttons of two screens. 

________________________________
REGARDING COMMENTS ON SUPREMELEARNING FROM NATIVE AMERICAN ENGLISH SPEAKERS

Ignore them. 

Most people of any native language have been conditioned by traditional teaching systems, which are ineffective with most people. Negative comments on the non-traditional SupremeLearning American English system should be expected from those conditioned in other ways. Traditional teachers will tend to have the loudest voices. SupremeLearning books are available to explain why this can be expected. 

The authors of SupremeLearning invite you to try any and all other teaching systems, whatever be their approaches, before or after using the SupremeLearning techniques. The authors then suggest that, rather than comparing the details of each of the methods, you compare your achieved results with each instead. 

________________________________
HOW SUPREMELEARNING WORKS 

Don't let it bother you if this is a mystery. You need not understand how the whole system works to achieve results. 

The main principles behind SupremeLearning any subject (which you can instantly apply to real life) are actually very simple. To memorize, retain, and recall any written data material you must:

1) Read each sentence outloud at least thrice (as demonstrated on the SupremeLearning tapes)

a) with different speeds, and 

b) sometimes very dramatically

2) Read outloud the separate words

3) Read outloud the same words letter-by-letter

4) Periodically write down or type - error-free - the words from the material, letter-by letter 

You can follow this style of learning in your everyday life for any subject and with any materials worth knowing. 

________________________________
IF THESE SUPREMELEARNING MATERIALS SEEM TO BE TOO DIFFICULT...

...you may need to start with a SupremeLearning book and/or its video tape version for beginners and/or a basic dictionary of the words used in the SupremeLearning course in your native language.  

The SupremeLearning audio tapes are for people whose native language is not American English but who know the English alphabet and can read in English. That's why the SupremeLearning book, audiobook, and videobook cover pages related to learning English are not translated into other languages. 

________________________________
TO ORDER MORE SUPREMELEARNING MATERIALS...

...including books, audiobooks, videobooks, and software call toll-free 1-888-743-7868 or 1-888-532-7677, or email to Wayward13@aol.com, or write to 

Wayward Ventures Publishing
29 John Street, Suite 188
New York NY 10038 USA

Full video courses will be available giving explicit explanations of phonetics and the SupremeLearning writing style, as well as much other important learning information. 

